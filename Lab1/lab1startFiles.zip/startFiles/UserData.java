package ece356;

public class UserData {

    String userName;
    String favColour;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String value) {
        userName = value;
    }

    public void setFavColour(String value) {
        favColour = value;
    }

    public String getFavColour() {
        return favColour;
    }
}